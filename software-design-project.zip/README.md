# Software-Design-Project

Our Software Design project for COSC 4353 at the University of Houston.

## Technologies

-  Database: MySQL
-  Backend: PHP
-  Frontend: HTML & Bootstrap CSS

## Authors

-  Michael Patrick Austin - [mpaustin1993](https://github.com/mpaustin1993)
-  Han Bui - [hbuiOnline](https://github.com/hbuiOnline)

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details
